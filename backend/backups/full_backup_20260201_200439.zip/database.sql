-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: crane_system
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `processes`
--

DROP TABLE IF EXISTS `processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `processes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` bigint DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_processes_code` (`code`),
  KEY `idx_processes_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processes`
--

LOCK TABLES `processes` WRITE;
/*!40000 ALTER TABLE `processes` DISABLE KEYS */;
INSERT INTO `processes` VALUES (1,'2026-01-31 20:26:31.604','2026-01-31 20:26:31.604',NULL,'吊臂制造','UP001','upper',1,'上车吊臂制造工序'),(2,'2026-01-31 20:26:31.606','2026-01-31 20:26:31.606',NULL,'转台制造','UP002','upper',2,'上车转台制造工序'),(3,'2026-01-31 20:26:31.608','2026-01-31 20:26:31.608',NULL,'底盘制造','LOW001','lower',1,'下车底盘制造工序'),(4,'2026-01-31 20:26:31.610','2026-01-31 20:26:31.610',NULL,'支腿制造','LOW002','lower',2,'下车支腿制造工序');
/*!40000 ALTER TABLE `processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_lines`
--

DROP TABLE IF EXISTS `production_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `process_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_production_lines_code` (`code`),
  KEY `idx_production_lines_deleted_at` (`deleted_at`),
  KEY `idx_production_lines_process_id` (`process_id`),
  CONSTRAINT `fk_processes_production_lines` FOREIGN KEY (`process_id`) REFERENCES `processes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_lines`
--

LOCK TABLES `production_lines` WRITE;
/*!40000 ALTER TABLE `production_lines` DISABLE KEYS */;
INSERT INTO `production_lines` VALUES (3,'2026-01-31 20:27:07.350','2026-01-31 20:27:07.350',NULL,'吊臂主臂生产线','UP_ARM_001','upper','主要负责起重机吊臂主臂的制造和装配','active',1),(4,'2026-01-31 20:27:07.352','2026-01-31 20:27:07.352',NULL,'吊臂副臂生产线','UP_ARM_002','upper','主要负责起重机吊臂副臂的制造和装配','active',1),(5,'2026-01-31 20:27:07.355','2026-01-31 20:27:07.355',NULL,'转台装配生产线','UP_TURN_001','upper','负责起重机转台的整体装配','active',2),(6,'2026-01-31 20:27:07.357','2026-01-31 20:27:07.357',NULL,'底盘焊接生产线','LOW_CHASSIS_001','lower','负责起重机底盘的焊接和初步成型','active',3),(7,'2026-01-31 20:27:07.359','2026-01-31 20:27:07.359',NULL,'支腿液压生产线','LOW_LEG_001','lower','负责起重机支腿液压系统的制造','active',4);
/*!40000 ALTER TABLE `production_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_files`
--

DROP TABLE IF EXISTS `program_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `program_id` bigint unsigned NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint DEFAULT NULL,
  `file_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_program_files_deleted_at` (`deleted_at`),
  KEY `idx_program_files_program_id` (`program_id`),
  KEY `idx_program_files_uploaded_by` (`uploaded_by`),
  CONSTRAINT `fk_program_files_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_programs_files` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_files`
--

LOCK TABLES `program_files` WRITE;
/*!40000 ALTER TABLE `program_files` DISABLE KEYS */;
INSERT INTO `program_files` VALUES (1,'2026-01-31 20:34:27.191','2026-01-31 20:34:27.191',NULL,1,'曲风.txt','uploads\\1_1769862867_曲风.txt',26124,'.txt','26.1.31',1,''),(2,'2026-01-31 21:33:00.150','2026-01-31 21:33:00.150',NULL,1,'pixelbead-pattern-1768031567934.png','1_1769866380_pixelbead-pattern-1768031567934.png',386428,'.png','26.2.1',1,''),(3,'2026-01-31 21:33:00.162','2026-01-31 21:33:00.162',NULL,1,'OIP-C.webp','1_1769866380_OIP-C.webp',4946,'.webp','26.2.1',1,''),(4,'2026-01-31 21:33:00.171','2026-01-31 21:33:00.171',NULL,1,'曲风.txt','1_1769866380_曲风.txt',26124,'.txt','26.2.1',1,'');
/*!40000 ALTER TABLE `program_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_relations`
--

DROP TABLE IF EXISTS `program_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_relations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `source_program_id` bigint unsigned NOT NULL,
  `related_program_id` bigint unsigned NOT NULL,
  `relation_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_program_relations_deleted_at` (`deleted_at`),
  KEY `idx_program_relations_source_program_id` (`source_program_id`),
  KEY `idx_program_relations_related_program_id` (`related_program_id`),
  CONSTRAINT `fk_program_relations_related_program` FOREIGN KEY (`related_program_id`) REFERENCES `programs` (`id`),
  CONSTRAINT `fk_program_relations_source_program` FOREIGN KEY (`source_program_id`) REFERENCES `programs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_relations`
--

LOCK TABLES `program_relations` WRITE;
/*!40000 ALTER TABLE `program_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `program_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_versions`
--

DROP TABLE IF EXISTS `program_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `program_id` bigint unsigned NOT NULL,
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_id` bigint unsigned NOT NULL,
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `change_log` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_current` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_program_versions_program_id` (`program_id`),
  KEY `idx_program_versions_uploaded_by` (`uploaded_by`),
  KEY `idx_program_versions_deleted_at` (`deleted_at`),
  KEY `fk_program_versions_file` (`file_id`),
  CONSTRAINT `fk_program_versions_file` FOREIGN KEY (`file_id`) REFERENCES `program_files` (`id`),
  CONSTRAINT `fk_program_versions_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_programs_versions` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_versions`
--

LOCK TABLES `program_versions` WRITE;
/*!40000 ALTER TABLE `program_versions` DISABLE KEYS */;
INSERT INTO `program_versions` VALUES (1,'2026-01-31 20:34:27.196','2026-01-31 21:33:00.173',NULL,1,'26.1.31',1,1,'',0),(2,'2026-01-31 21:33:00.157','2026-01-31 21:33:00.173',NULL,1,'26.2.1',2,1,'',0),(3,'2026-01-31 21:33:00.167','2026-01-31 21:33:00.173',NULL,1,'26.2.1',3,1,'',0),(4,'2026-01-31 21:33:00.176','2026-01-31 21:33:00.176',NULL,1,'26.2.1',4,1,'',1);
/*!40000 ALTER TABLE `program_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `production_line_id` bigint unsigned NOT NULL,
  `vehicle_model_id` bigint unsigned DEFAULT NULL,
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `idx_programs_deleted_at` (`deleted_at`),
  KEY `idx_programs_production_line_id` (`production_line_id`),
  KEY `idx_programs_vehicle_model_id` (`vehicle_model_id`),
  CONSTRAINT `fk_production_lines_programs` FOREIGN KEY (`production_line_id`) REFERENCES `production_lines` (`id`),
  CONSTRAINT `fk_vehicle_models_programs` FOREIGN KEY (`vehicle_model_id`) REFERENCES `vehicle_models` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,'2026-01-31 20:33:40.019','2026-01-31 21:33:00.178','2026-02-01 19:39:46.282','1','1',3,2,'26.2.1','123','active');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `production_line_id` bigint unsigned NOT NULL,
  `can_view` tinyint(1) DEFAULT '1',
  `can_download` tinyint(1) DEFAULT '0',
  `can_upload` tinyint(1) DEFAULT '0',
  `can_manage` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_user_permissions_user_id` (`user_id`),
  KEY `idx_user_permissions_production_line_id` (`production_line_id`),
  KEY `idx_user_permissions_deleted_at` (`deleted_at`),
  CONSTRAINT `fk_user_permissions_production_line` FOREIGN KEY (`production_line_id`) REFERENCES `production_lines` (`id`),
  CONSTRAINT `fk_user_permissions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `employee_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `employee_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_users_employee_id` (`employee_id`),
  KEY `idx_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2026-01-31 20:21:03.998','2026-01-31 21:36:27.270',NULL,'admin001','系统管理员','工艺研究所','admin','$2a$10$pPL1gyRKlhIOS0Z3sUxTgO7I9ZdhtDMlCCCtqAd7Hbs8glA7LGHSK','active',NULL),(2,'2026-02-01 19:47:17.600','2026-02-01 19:47:17.600',NULL,'test001','Test User','Test','user','$2a$10$PsFFaDSji1sOWbqHv.3fKu8CMV.h2uSsqG1LxrgJa5HGlEAK/hT8m','active','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicle_models`
--

DROP TABLE IF EXISTS `vehicle_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle_models` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT NULL,
  `updated_at` datetime(3) DEFAULT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `series` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vehicle_models_code` (`code`),
  KEY `idx_vehicle_models_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_models`
--

LOCK TABLES `vehicle_models` WRITE;
/*!40000 ALTER TABLE `vehicle_models` DISABLE KEYS */;
INSERT INTO `vehicle_models` VALUES (1,'2026-01-31 20:23:51.188','2026-01-31 20:23:51.188',NULL,'ZTC10000','1','汽车起重机','','active'),(2,'2026-01-31 20:26:45.216','2026-01-31 20:26:45.216',NULL,'25吨汽车起重机','QC25','QC系列','25吨汽车起重机，适用于中小型建筑工地','active'),(3,'2026-01-31 20:26:45.221','2026-01-31 20:26:45.221',NULL,'50吨汽车起重机','QC50','QC系列','50吨汽车起重机，适用于中型工程项目','active'),(4,'2026-01-31 20:26:45.222','2026-01-31 20:26:45.222',NULL,'80吨汽车起重机','QC80','QC系列','80吨汽车起重机，适用于大型工程项目','active'),(5,'2026-01-31 20:26:45.224','2026-01-31 20:26:45.224',NULL,'100吨汽车起重机','QC100','QC系列','100吨汽车起重机，适用于重型工程项目','active');
/*!40000 ALTER TABLE `vehicle_models` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-01 20:04:40
